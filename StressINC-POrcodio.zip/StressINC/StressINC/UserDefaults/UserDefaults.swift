//
//  UserDefaults.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import Foundation
import UIKit

let continue_bool = UserDefaults.standard.bool(forKey: "continue")

var actualMoney = UserDefaults.standard.double(forKey: "ActualMoney")

// Inizio Employee

var employeeFemaleUnlockedImage = UIImage(named: "EmployeeFemale.png")
var employeeFemaleLockedImage = UIImage(named: "EmployeeFemaleLocked.png")

var employeeElfUnlockedImage = UIImage(named: "EmployeeElf.png")
var employeeElfLockedImage = UIImage(named: "EmployeeElfLocked.png")

var employeeTurtleUnlockedImage = UIImage(named: "EmployeeTurtle.png")
var employeeTurtleLockedImage = UIImage(named: "EmployeeTurtleLocked.png")

var employeeEvilDevilUnlockedImage = UIImage(named: "EmployeeEvilDevil.png")
var employeeEvilDevilLockedImage = UIImage(named: "EmployeeEvilDevilLocked.png")

var employeeBandanaUnlockedImage = UIImage(named: "EmployeeBandana.png")
var employeeBandanaLockedImage = UIImage(named: "EmployeeBandanaLocked.png")

var employeeIceCreamUnlockedImage = UIImage(named: "EmployeeIceCream.png")
var employeeIceCreamLockedImage = UIImage(named: "EmployeeIceCreamLocked.png")

var employeeMageUnlockedImage = UIImage(named: "EmployeeMage")
var employeeMageLockedImage = UIImage(named: "EmployeeMageLocked")

var employeeNinjaUnlockedImage = UIImage(named: "EmployeeNinja")
var employeeNinjaLockedImage = UIImage(named: "EmployeeNinjaLocked")

var employeeMummyUnlockedImage = UIImage(named: "EmployeeMummy")
var employeeMummyLockedImage = UIImage(named: "EmployeeMummyLocked")

var employeeClownUnlockedImage = UIImage(named: "EmployeeClown")
var employeeClownLockedImage = UIImage(named: "EmployeeClownLocked")

var employeePharaohUnlockedImage = UIImage(named: "EmployeePharaoh")
var employeePharaohLockedImage = UIImage(named: "EmployeePharaohLocked")

var employeeActualStress1 = UIImage(named: "StressBar1")
var employeeActualStress2 = UIImage(named: "StressBar2")
var employeeActualStress3 = UIImage(named: "StressBar3")
var employeeActualStress4 = UIImage(named: "StressBar4")
var employeeActualStress5 = UIImage(named: "StressBar5")
var employeeActualStress6 = UIImage(named: "StressBar6")
var employeeActualStress7 = UIImage(named: "StressBar7")
var employeeActualStress8 = UIImage(named: "StressBar8")
var employeeActualStress9 = UIImage(named: "StressBar9")
var employeeActualStress10 = UIImage(named: "StressBar10")
var employeeActualStress11 = UIImage(named: "StressBar11")

    
let employeeFemale = Employee(image: employeeFemaleUnlockedImage!,imageWhenLocked: employeeFemaleLockedImage!, name: "Sarah", description: "Hire this employee to know his description", isHired: true, isWorking: false, alphaEmployee: 1.0, stressIncrement: 2, actualStress: 35 , priceForHiring: 0)

let employeeElf = Employee(image: employeeElfUnlockedImage!,imageWhenLocked: employeeElfLockedImage!, name: "HightDruid", description: "", isHired: true, isWorking: false, alphaEmployee: 1.0, stressIncrement: 3, actualStress: 30, priceForHiring: 0)

let employeeTurtle = Employee(image: employeeTurtleUnlockedImage!,imageWhenLocked: employeeTurtleLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 50)

let employeeEvilDevil = Employee(image: employeeEvilDevilUnlockedImage!,imageWhenLocked: employeeEvilDevilLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 100)

let employeeBandana = Employee(image: employeeBandanaUnlockedImage!,imageWhenLocked: employeeBandanaLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 200)

let employeeIceCream = Employee(image: employeeIceCreamUnlockedImage!,imageWhenLocked: employeeIceCreamLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 400)

let employeeMage = Employee(image: employeeMageUnlockedImage!,imageWhenLocked: employeeMageLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 800)

let employeeNinja = Employee(image: employeeNinjaUnlockedImage!,imageWhenLocked: employeeNinjaLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 1500)

let employeeMummy = Employee(image: employeeMummyUnlockedImage!,imageWhenLocked: employeeMummyLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 3000)

let employeeClown = Employee(image: employeeClownUnlockedImage!,imageWhenLocked: employeeClownLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 5000)

let employeePharaoh = Employee(image: employeePharaohUnlockedImage!,imageWhenLocked: employeePharaohLockedImage!, name: "Jason", description: "SDASD", isHired: false, isWorking: false, alphaEmployee: 0, stressIncrement: 0, actualStress: 0, priceForHiring: 10000)
    
// Fine employee
// Inizio Tasks

let taskImage = UIImage(named: "Contract")


let task1 = Task(image: taskImage!, description: "Start a big paperplane war.", name: "Serius Business.", isActive: false, revenue: 10000, duration: 60, stressMulti: 0)

let task2 = Task(image: taskImage!, description: "Focus on your work for at least 5 minutes.", name: "Not Really Challenging Task", isActive: false, revenue: 50000, duration: 300, stressMulti: 0)

let task3 = Task(image: taskImage!, description: "Hack your rival company.", name: "Mhackeroni", isActive: false, revenue: 150000, duration: 600, stressMulti: 0)

let task4 = Task(image: taskImage!, description: "Commemorate your first time being punctual at work.", name: "The Achivement", isActive: false, revenue: 1000, duration: 5, stressMulti: 0)

let task5 = Task(image: taskImage!, description: "Learn something new today.", name: "Normie Task", isActive: false, revenue: 5000, duration: 30, stressMulti: 0)

let neededTask1time = task1.duration
let neededTask2time = task2.duration
let neededTask3time = task3.duration
let neededTask4time = task4.duration
let neededTask5time = task5.duration


// Fine Tasks

//Inizio Item

var itemCatImage = UIImage(named: "ItemCat")
var itemUnexpectedImage = UIImage(named: "ItemUnexpected")


let itemCat = Item(image: itemCatImage!, name: "Cat", description: "Purrrrr", cost: 10)

let itemUnexpected = Item(image: itemUnexpectedImage!, name: "What will happen?", description: "Boh nun o sacc uagliu", cost: 20)




