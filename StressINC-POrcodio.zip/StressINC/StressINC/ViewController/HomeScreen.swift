//
//  HomeScreen.swift
//  StressINC
//
//  Created by Gennaro Rivetti on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import UIKit

class HomeScreen: UIViewController {

    @IBOutlet var background: UIImageView!
    
    @IBOutlet var StartGameButton: UIButton!
    @IBOutlet var ContinueGameButton: UIButton!
    
    override func viewDidLoad(){
        
        UserDefaults.standard.bool(forKey: "continue")
        
        print("\(continue_bool)")
        super.viewDidLoad()
        background.loadGif(name: "MainBackGround")
        // Do any additional setup after loading the view.
        
    }
    


    
    @IBAction func NewGame_action(_ sender: Any) {
        UserDefaults.standard.set(true, forKey: "continue")
        performSegue(withIdentifier: "StartGamePresent", sender: self)
    }
    
    @IBAction func Continue_action(_ sender: Any) {
        performSegue(withIdentifier: "ContinuePresent", sender: self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        // BOTTONE CONTINUE
        
        if continue_bool{
            ContinueGameButton.isUserInteractionEnabled = true
        }
        else
        {
            ContinueGameButton.isUserInteractionEnabled = false
        }
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
