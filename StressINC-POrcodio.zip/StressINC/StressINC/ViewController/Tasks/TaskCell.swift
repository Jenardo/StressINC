//
//  TaskCell.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import UIKit

class TaskCell: UITableViewCell
{
    
    var employeeItem: Employee!
    
    // TIMER

    var timer = Timer()
    var isTimerRunning = false
    var seconds = 0

    func runTimer() {
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
        
    }

    @objc func updateTimer() -> Int
    {
        
        seconds += 1
        return seconds
        //This will decrement(count down)the seconds.
    }
    
    //This will be used to make sure only one timer is created at a time.
    
    @IBOutlet weak var taskDescriptionLabel: UILabel!
    @IBOutlet weak var taskImageView: UIImageView!
    @IBOutlet weak var taskNameLabel: UILabel!
    @IBOutlet weak var taskDurationLabel: UILabel!
    @IBOutlet weak var taskRevenueLabel: UILabel!
    
    var taskItem: Task!
    
    func setTask(task: Task)
    {
            
        taskItem = task
            
        taskDescriptionLabel.text = task.description
        taskImageView.image = task.image
        taskNameLabel.text = task.name
        taskDurationLabel.text = "Task time required: \(task.duration)"
        taskRevenueLabel.text = "$:\(task.revenue)"
            

            
    //        if taskItem.isActive == true
    //        {
    //
    //
    //            while(updateTimer() < taskItem.duration)
    //            {
    //                employeeItem.actualStress = employeeItem.stressIncrement * taskItem.stressMulti
    //
    //
    //
    //                if(updateTimer() == taskItem.duration)
    //                {
    //
    //                    actualMoney = actualMoney + taskItem.revenue
    //
    //                }
    //            }
    //
    //        taskItem.isActive = false
    //
    //        }
            
        }
    
    @IBAction func assignTaskButton(_ sender: Any)
    {
        taskItem.isActive = true
//        setTask(task: taskItem)
    }
    
//    func setTask(task: Task)
//    {
//
//        taskItem = task
//
//        taskDescriptionLabel.text = taskItem.description
//        taskImageView.image = taskItem.image
//        taskNameLabel.text = taskItem.name
//        taskDurationLabel.text = String(taskItem.duration)
//        taskRevenueLabel.text = String(taskItem.revenue)
//
//
//
//        if taskItem.isActive == true
//        {
//
//
//            while(updateTimer() < taskItem.duration)
//            {
//                employeeItem.actualStress = employeeItem.stressIncrement * taskItem.stressMulti
//
//
//
//                if(updateTimer() == taskItem.duration)
//                {
//
//                    actualMoney = actualMoney + taskItem.revenue
//
//                }
//            }
//
//        taskItem.isActive = false
//
//        }
        
}

