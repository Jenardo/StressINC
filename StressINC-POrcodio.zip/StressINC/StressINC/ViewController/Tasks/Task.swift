//
//  Task.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import UIKit

class Task
{
    var image: UIImage
    var description: String
    var name: String
    var isActive = UserDefaults.standard.bool(forKey: "isActive")
    var revenue: Double
    var duration: Int
    var stressMulti: Double
    
    init(image: UIImage, description: String, name: String, isActive: Bool, revenue: Double, duration: Int, stressMulti: Double)
    {
        
        self.image = image
        self.description = description
        self.name = name
        self.isActive = isActive
        self.revenue = revenue
        self.duration = duration
        self.stressMulti = stressMulti
        
    }
    
}
