//
//  TaskListView.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import UIKit

class TaskListView: UIViewController
{
    
    var TaskTableViewTimer: Timer?
    
    @IBOutlet weak var taskTableView: UITableView!
    
    var tasks: [Task] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        tasks.append(task1)
        tasks.append(task2)
        tasks.append(task3)
        tasks.append(task4)
        tasks.append(task5)
        
        taskTableViewUpdate()
    }
    
    func taskTableViewUpdate()
    {
        
        TaskTableViewTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(taskTableViewCheck), userInfo: nil, repeats: true)
        
        
    }
    
    @objc func taskTableViewCheck()
    {
        taskTableView.reloadData()
    }
}

extension TaskListView: UITableViewDataSource, UITableViewDelegate
    {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let task = tasks[indexPath.row]

        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell") as! TaskCell
        
        cell.setTask(task: task)
        
        return cell
    }
    
}
