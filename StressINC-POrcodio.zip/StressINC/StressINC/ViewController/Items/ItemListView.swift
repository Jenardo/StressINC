//
//  TaskListView.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import UIKit

class ItemListView: UIViewController
{

    var itemTableViewTimer: Timer?
    
    @IBOutlet weak var itemTableView: UITableView!
    
    var items: [Item] = []
    
    override func viewDidLoad()
    {
        items.append(itemCat)
        items.append(itemUnexpected)
        
        itemTableViewUpdate()
        
        super.viewDidLoad()
        
    }
    
    
    func itemTableViewUpdate()
    {
        itemTableViewTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(itemTableViewCheck), userInfo: nil, repeats: true)
    }
    
    @objc func itemTableViewCheck()
    {
        itemTableView.reloadData()
    }
    
    
}



extension ItemListView: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let item = items[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell") as! ItemCell
        
        cell.setItem(item: item)
        
        return cell
    }
}
