//
//  Items.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import Foundation
import UIKit

class Item
{
    var image: UIImage
    var name: String
    var description: String
    var cost: Double
    
    init(image: UIImage, name: String, description: String, cost: Double)
    {
        self.image = image
        self.name = name
        self.description = description
        self.cost = cost
    }
}
