//
//  TaskListVIew.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import UIKit

class ItemCell: UITableViewCell
{

    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var itemNameLabel: UILabel!
    @IBOutlet weak var itemDescriptionLabel: UILabel!
    @IBOutlet weak var itemCostLabel: UILabel!
    
    var itemItem: Item!
    
    func setItem(item: Item)
    {
        itemItem = item
        
        itemImageView.image = item.image
        itemNameLabel.text = item.name
        itemDescriptionLabel.text = item.description
        itemCostLabel.text = "$: \(item.cost)"
    }
    
    
    @IBAction func didTapBuyItem(_ sender: Any)
    {
        
    }
    
    
}
