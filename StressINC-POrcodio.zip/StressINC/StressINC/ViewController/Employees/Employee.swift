//
//  Employee.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import Foundation
import UIKit

class Employee
{
    var image: UIImage
    var imageWhenLocked: UIImage
    var name: String
    var description: String
    var isHired = UserDefaults.standard.bool(forKey: "isEmployeeHired")
    var isWorking = UserDefaults.standard.bool(forKey: "isEmployeeWorking")
    var alphaEmployee = UserDefaults.standard.double(forKey: "alphaEmployee")
    var stressIncrement: Double
    var actualStress = UserDefaults.standard.double(forKey: "actualStress")
    var priceForHiring: Double
    
    init(image: UIImage, imageWhenLocked: UIImage, name: String, description: String, isHired: Bool, isWorking: Bool, alphaEmployee : Double, stressIncrement: Double, actualStress: Double, priceForHiring: Double)
    {
        
        self.image = image
        self.name = name
        self.description = description
        self.isHired = isHired
        self.imageWhenLocked = imageWhenLocked
        self.isWorking = isWorking
        self.stressIncrement = stressIncrement
        self.actualStress = actualStress
        self.priceForHiring = priceForHiring
        self.alphaEmployee = alphaEmployee
        
    }
}
