//
//  EmployeeCell.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.
//

import UIKit

class EmployeeCell: UITableViewCell
{

    @IBOutlet weak var employeeImageView: UIImageView!
    @IBOutlet weak var employeeDescriptionLabel: UILabel!
    @IBOutlet weak var employeeNameLabel: UILabel!
    @IBOutlet weak var employeeStressImageView: UIImageView!
    @IBOutlet weak var employeeHireCostLabel: UILabel!
    
 
    
    @IBAction func hireButton(_ sender: Any)
    {
        if actualMoney >= employeeItem.priceForHiring
            && employeeItem.isHired == false
        {
            
            employeeItem.isHired = true
            UserDefaults.standard.set(employeeItem.isHired, forKey: "\(String(describing: employeeItem))")
            
            actualMoney = actualMoney - employeeItem.priceForHiring
            UserDefaults.standard.set(actualMoney, forKey: "ActualMoney")
            
            print(actualMoney as Any)
            
        }
        
        else
        {
            _ = 0
            print("NOT MONEY")
        }
    }
    
    var employeeItem: Employee!
    
    func setEmployee(employee: Employee)
    {
        employeeItem = employee
        
        if employeeItem.isHired == true
            
        {
            employeeStressImageView.alpha = 1
            employeeImageView.image = employee.image
            employeeDescriptionLabel.text = employee.description
            employeeNameLabel.text = employee.name
            employeeHireCostLabel.text = "HIRED"
            
            if employee.actualStress <= 10
            {
                employeeStressImageView.image = employeeActualStress1
            }
            
            else if employee.actualStress <= 20
            {
                employeeStressImageView.image = employeeActualStress2
            }
            
            else if employee.actualStress <= 30
            {
                employeeStressImageView.image = employeeActualStress3
            }
            
            else if employee.actualStress <= 40
            {
                employeeStressImageView.image = employeeActualStress4
            }
            
            else if employee.actualStress <= 50
            {
                employeeStressImageView.image = employeeActualStress5
            }
                
            else if employee.actualStress <= 60
            {
                employeeStressImageView.image = employeeActualStress6
            }
                
            else if employee.actualStress <= 70
            {
                employeeStressImageView.image = employeeActualStress7
            }
            
            else if employee.actualStress <= 80
            {
                employeeStressImageView.image = employeeActualStress8
            }
            
            else if employee.actualStress <= 90
            {
                employeeStressImageView.image = employeeActualStress9
            }
            
            else if employee.actualStress <= 100
            {
                employeeStressImageView.image = employeeActualStress10
            }
            
            else if employee.actualStress <= 110
            {
                employeeStressImageView.image = employeeActualStress11
            }
            
            else if employee.actualStress > 110
            {
                
                employee.actualStress = 60
                actualMoney = actualMoney - 100.00
                UserDefaults.standard.set(actualMoney, forKey: "ActualMoney")
                
            }
        }
        
        else
            
        {
            employeeImageView.image = employee.imageWhenLocked
            employeeDescriptionLabel.text = "Unlock this character to see his description"
            employeeNameLabel.text = "???"
            employeeHireCostLabel.text = "$: \(employee.priceForHiring)"
            employeeStressImageView.alpha = 0
        }
    }
    

    
}
