//
//  EmployeeListView.swift
//  StressINC
//
//  Created by Giuseppe Monfregola on 21/11/2019.
//  Copyright © 2019 Gennaro Rivetti. All rights reserved.

import UIKit

class EmployeeListView: UIViewController
{
    
    var employeeTableViewTimer: Timer?
    
    @IBOutlet weak var employeeTableView: UITableView!
    
    var employees: [Employee] = []
    
    override func viewDidLoad()
    {
        
        super.viewDidLoad()
        
        employees.append(employeeFemale)
        employees.append(employeeElf)
        employees.append(employeeTurtle)
        employees.append(employeeEvilDevil)
        employees.append(employeeBandana)
        employees.append(employeeIceCream)
        employees.append(employeeMage)
        employees.append(employeeNinja)
        employees.append(employeeMummy)
        employees.append(employeeClown)
        employees.append(employeePharaoh)
        
        employeeTableViewUpdate()
        

    }
    
    func employeeTableViewUpdate()
    {
        employeeTableViewTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(employeeTableViewCheck), userInfo: nil, repeats: true)
    }

    @objc func employeeTableViewCheck()
    {
        employeeTableView.reloadData()
    }
}




extension EmployeeListView: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return employees.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let employee = employees[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmployeeCell") as! EmployeeCell
        
        cell.setEmployee(employee: employee)
        
        return cell
    }
    
}
